extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_quit_pressed() -> void:
	get_tree().change_scene_to_file("res://title_screen.tscn")


func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("menu_1.tscn")


func _on_tutorial_pressed() -> void:
	get_tree().change_scene_to_file("res://tutorial.tscn")


func _on_save_pressed() -> void:
	get_tree().change_scene_to_file("res://Save_screen.tscn")
