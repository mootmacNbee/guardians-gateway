extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed('interact'):
		get_tree().change_scene_to_file('res://City_1.tscn')


func _on_left_click_to_continuenot_working_pressed() -> void:
	get_tree().change_scene_to_file('res://City_1.tscn')
