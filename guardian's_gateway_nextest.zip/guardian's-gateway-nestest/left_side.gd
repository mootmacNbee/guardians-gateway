extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$"../CharacterBody3D/Camera3D".rotation.y = clamp($"../CharacterBody3D/Camera3D".rotation.y, -134.1, --41.0)
		
	if Input.is_action_pressed("turn camera right"):
		if mouse_entered:
			print("1-2")
			$"../CharacterBody3D/Camera3D".rotation.y -= 0.02
			print("2-2")
	if Input.is_action_pressed("turn camera left"):
		if mouse_entered:
			print("1-2")
			$"../CharacterBody3D/Camera3D".rotation.y += 0.02
			print("2-2")
